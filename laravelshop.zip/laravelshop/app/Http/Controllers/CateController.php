<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Requests\CateRequest;
use App\Cate;


class CateController extends Controller
{
    //
    public function getList()
    {
        //lay du lieu
        $data = Cate::select('id','name','parent_id')->orderBy('id','DESC')->get()->toArray();
    	return view('catelist',compact('data'));
    }
    public function getAdd()
    {
        $parent = Cate::select('id','name','parent_id')->get()->toArray();
    	return view('cateadd',compact('parent'));
    }

    public function postAdd(CateRequest $request)
    {
    	$cate = new Cate;
    	$cate->name 		= $request->txtCateName;
    	$cate->alias 		= changeTitle($request->txtCateName);
    	$cate->order 		= $request->txtOrder;
    	$cate->parent_id	= $request->sltParent;
    	$cate->keywords 	= $request->txtKeywords;
    	$cate->description 	= $request->txtDescription;
    	$cate->save();
    	return redirect()->route('admin.cate.list')->with(['flash_level'=>'success','flash_message'=>'Success !! Complete Add Category']);//xuat hien thong bao add thanh cong
    }
    public function getDelete($id)
    {   
        $parent = Cate::where('parent_id',$id)->count();
        if($parent == 0)
        {
            $cate = Cate::find($id);
            $cate->delete($id);
            return redirect()->route('admin.cate.list')->with(['flash_level'=>'success','flash_message'=>'Success !! Complete deleting']);
        }
        else
        {
            echo "<script type='text/javascript'>
                alert('Sorry ! You CAN NOT DELETE this Category');
                window.location = '";
                    echo route('admin.cate.list');
                echo"'


            </script>";
        }
        
    }
    public function getEdit($id)
    {
        $data = Cate::findOrFail($id)->toArray();
         $parent = Cate::select('id','name','parent_id')->get()->toArray();
        return view('cateedit',compact('parent','data'));
    }
    public function postEdit(Request $request,$id)
    {
        // khong tao ra trang request
        //su dung request mac dinh cua Laravel 5
        $this->validate($request,
            ["txtCateName"  =>   "required"],
            ["txtCateName.required"  =>  "Please Enter Name Category 1"]
        );
        $cate = Cate::find($id);  // tim ra id can update lai
        $cate->name         = $request->txtCateName;
        $cate->alias        = changeTitle($request->txtCateName);
        $cate->order        = $request->txtOrder;
        $cate->parent_id    = $request->sltParent;
        $cate->keywords     = $request->txtKeywords;
        $cate->description  = $request->txtDescription;
        $cate->save();
         return redirect()->route('admin.cate.list')->with(['flash_level'=>'success','flash_message'=>'Success !! Complete Edit Category ']);

    }
 }
