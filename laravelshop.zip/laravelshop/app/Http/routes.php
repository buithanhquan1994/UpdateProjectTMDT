<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
// dat ten route trang
Route::get('/product',[
	'as'	=>	'product.show',
	'uses'	=>	'showproduct@show'
	]);
Route::get('/category',[
	'as'	=>	'category.show',
	'uses'	=>	'CateController@showcate'
	]);

Route::get('/shoppingcart',[
	'as'	=>	'shoppingcart.show',
	'uses'	=> 	'ShowShoppingCart@show'
	]);

Route::get('/checkout',[
	'as'	=>	'checkout.show',
	'uses'	=>	'Checkout@show'
	]);

Route::get('/login',[
	'as'	=>	'login.show',
	'uses'	=>	'Account@login'
	]);

Route::get('/register',[
	'as'	=>	'register.show',
	'uses'	=>	'Account@register'
	]);

Route::get('/contact',[
	'as'	=>	'contact.show',
	'uses'	=>	'Contact@show'
	]);
// Authentication routes
Route::get('auth/login','Auth\AuthController@getLogin');


Route::group(['prefix'=>'admin'],function()
{
	Route::group(['prefix'=>'cate'],function()
	{
		Route::get('list',['as'=>'admin.cate.list','uses'=>'CateController@getList']);
		Route::get('add',['as'=>'admin.cate.getAdd','uses'=>'CateController@getAdd']);
		Route::post('add',['as'=> 'admin.cate.postAdd','uses'=>'CateController@postAdd']);
		Route::get('delete/{id}',['as'=>'admin.cate.getDelete','uses'=>'CateController@getDelete']);
		Route::get('edit/{id}',['as'=>'admin.cate.getEdit','uses'=>'CateController@getEdit']);
		Route::post('edit/{id}',['as'=>'admin.cate.postEdit','uses'=>'CateController@postEdit']);
	});

	//Quan ly trang product
	Route::group(['prefix'=>'product'],function() {
		Route::get('list',['as'=>'admin.product.list','uses'=>'ProductController@getList']);
		Route::get('add',['as'=>'admin.product.getAdd','uses'=>'ProductController@getAdd']);
		Route::post('add',['as'=>'admin.product.postAdd','uses'=>'ProductController@postAdd']);
		Route::get('delete/{id}',['as'=>'admin.product.getDelete','uses'=>'ProductController@getDelete']);
		Route::get('edit/{id}',['as'=>'admin.product.getEdit','uses'=>'ProductController@getEdit']);
		Route::post('edit/{id}',['as'=>'admin.product.postEdit','uses'=>'ProductController@postEdit']);
		Route::get('delimg/{id}',['as'=>'admin.product.getDelImg','uses'=>'ProductController@getDelImg']);
	});
});



Route::get('/trang-chu',function()
{
	return view('user.pages.home');
});


Route::get('/cateedit',function()
{
	return view('cateedit');
});


