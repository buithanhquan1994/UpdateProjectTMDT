<?php

function stripUnicode($str){
	if(!$str) return false;
	$unicode = array(
		'a'	=>	'á|à|ả|ã|ạ|ă|ắ|ằ|ẳ|ẵ|ặ|ấ|â|ầ|ẩ|ẫ|ậ',
		'A'	=>	'Á|À|Ả|Ã|Ạ|Ắ|Ă|Ằ|Ẳ|Ẵ|Ặ|Ấ|Ầ|Ẩ|Ẫ|Ậ|Â',
		'd'	=>	'đ',
		'D'	=>	'Đ',
		'e'	=>	'é|è|ẻ|ẽ|ẹ|ế|ề|ể|ễ|ệ|ê',
		'E'	=>	'É|È|Ẻ|Ẽ|Ẹ|Ế|Ề|Ể|Ễ|Ệ|Ê',
		'i'	=>	'í|ì|ỉ|ĩ|ị',
		'I'	=>	'Í|Ì|Ỉ|Ĩ|Ị',
		'o'	=>	'ó|ò|ỏ|õ|ọ|ơ|ớ|ờ|ở|ỡ|ợ|ô|ố|ồ|ổ|ỗ|ộ',
		'O'	=>	'Ó|Ò|Ỏ|Ọ|Õ|Ớ|Ờ|Ở|Ơ|Ỡ|Ợ|Ố|Ồ|Ô|Ổ|Ỗ|Ộ',
		'u'	=>	'ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự|',
		'U'	=> 	'Ú|Ù|Ủ|Ũ|Ụ|Ư|Ứ|Ừ|Ử|Ữ|Ự',
		'y'	=>	'ý|ỳ|ỷ|ỵ|ỹ',
		'Y'	=>	'Ý|Ỳ|Ỷ|Ỹ|Ỵ'
	);
	foreach ($unicode as $khongdau => $codau) {
		$arr=explode("|", $codau);
		$str= str_replace($arr, $khongdau, $str);
	}
	return $str;
	
}

function changeTitle($str){
	$str=trim($str);
	if($str=="") return "";
	$str = str_replace('"', '',$str);
	$str = str_replace("'", '', $str);
	$str = stripUnicode($str);
	$str = mb_convert_case($str, MB_CASE_LOWER,'utf-8');
	$str = str_replace(' ', '-', $str);
	return $str;
}
//tao menu da cap
function cate_parent($data,$parent =0, $str="--",$select=0) {

	foreach($data as  $val)
	{
		$id = $val["id"];
		$name = $val["name"];

		if($val["parent_id"] == $parent)
		{
			if($select != 0 && $id == $select){
				echo "<option value='$id' selected='selected'>$str $name</option>";
			}
			else{
				echo "<option value='$id'>$str $name</option>";
			}
			
			cate_parent($data,$id, $str.">>",$select);
		}
		
	}
}
?>